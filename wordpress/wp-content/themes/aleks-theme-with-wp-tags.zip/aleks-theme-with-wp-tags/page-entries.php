<?php get_header(); ?>

<!-- main content -->
	<div class="main-content">
		<div class="row"> <!-- start row -->
			<div class="col-md-4"> <!-- start three column -->
				<h2>Lessons</h2>
				<a class="btn" href="#">read more</a>
			</div>
			<div class="col-md-4">
				<h2>Studies</h2>
				<a class="btn" href="#">read more</a>			
			</div>
			<div class="col-md-4"> <!-- end three column -->
				<h2>Experiments</h2>
				<a class="btn" href="#">read more</a>			
			</div>						
		</div> <!-- end row -->
	</div>
<!-- end main content -->

<?php wp_footer(); ?>