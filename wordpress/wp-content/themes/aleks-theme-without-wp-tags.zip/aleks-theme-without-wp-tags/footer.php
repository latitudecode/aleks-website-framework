<footer>		

</footer>

</div>
    <script src="/js/bootstrap.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/npm.js"></script>	    
</body>
</html>
