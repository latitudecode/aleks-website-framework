<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta content="test">
<!-- This is a website for Aleks Degtyarev -->
<!-- core css -->
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/normalize.css" />
<link rel="stylesheet" type="text/css" href="css/custom.css" />
<link rel="stylesheet" type="text/css" href="css/media.css" /> 
<!-- font awesome for icons -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
<!-- make it responsive -->
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!-- hover action -->
<link rel="stylesheet" type="text/css" href="css/hover.css" />	
<!-- form css -->
<link rel="stylesheet" type="text/css" href="css/forms.css" />	
<!-- google analytics -->
<!-- google fonts -->
</head>
<body>
<div class="wrapper">

	<header>

	</header>