<!-- main content -->
	<div class="main-content">
		<div class="main-entries row"> <!-- start row -->
			<div class="col-md-4 studies"> <!-- start three column -->
				<h2>Studies</h2>
				<p>coming soon</p>
			</div>
			<div class="col-md-4 lessons">
				<h2>Lessons</h2>
				<a class="btn" href="page-list.html">read more</a>			
			</div>
			<div class="col-md-4 experiments"> <!-- end three column -->
				<h2>Experiments</h2>
				<p>coming soon</p>			
			</div>						
		</div> <!-- end row -->
	</div>
<!-- end main content -->