<body>

<!-- back btn -->
		<div class="back">
			<a href="index.html">back to home</a>
		</div>
<!-- end back btn -->

<div class="wrapper">

	<header>

	</header>

<!-- main content -->
	<div class="main-content page-list">
		<div class="row"> <!-- start row -->
			<div class="col-md-12">
				<h1>Lessons</h1>
			</div>
		</div> <!-- end row -->
		<div class="row"> <!-- start row -->
			<div class="col-md-4"> <!-- start three column -->
				<ul> <!-- start post list -->
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>																										
				</ul> <!-- end post list -->
			</div>
			<div class="col-md-4">
<ul> <!-- start post list -->
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>																										
				</ul> <!-- end post list -->		
			</div>
			<div class="col-md-4"> <!-- end three column -->
<ul> <!-- start post list -->
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>
					<li>
						<a class="btn" href="single.html">
							<h2>Title of lesson</h2>
						</a>
					</li>																										
				</ul> <!-- end post list -->			
			</div>						
		</div> <!-- end row -->
	</div>
<!-- end main content -->