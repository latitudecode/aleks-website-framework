<body>

<!-- back btn -->
		<div class="back">
			<a href="page-list.html">back to lessons</a>
		</div>
<!-- end back btn -->

<div class="wrapper">

	<header>

	</header>

<!-- main content -->
	<div class="main-content">
		<div class="row post-content"> <!-- start row -->
			<div class="col-md-12"> <!-- start three column -->
				<h1>Title of lesson</h1>
			</div>						
		</div> <!-- end row -->
		<div class="row post-content"> <!-- start row -->
			<div class="col-md-12"> <!-- start three column -->
				<h2>sub title</h2>
				<p>Pinterest High Life authentic Blue Bottle squid. Fixie hella tousled, beard organic scenester pour-over Blue Bottle seitan trust fund twee fap. Pork belly butcher seitan cray 3 wolf moon. Actually selfies YOLO PBR&B tousled PBR. Cray Portland banjo, mlkshk Wes Anderson four loko flannel distillery twee tilde bicycle rights small batch. Gastropub church-key narwhal four dollar toast leggings next level. Hoodie raw denim meditation you probably haven't heard of them letterpress.
				<br />
				<br />
				Vinyl vegan sartorial aesthetic bitters hella. <a href="#">Neutra bitters</a> tousled locavore, hashtag trust fund bespoke Blue Bottle. Four dollar toast sriracha organic, twee hella Tumblr flannel keffiyeh beard polaroid cray put a bird on it. Swag four dollar toast cred pop-up. Occupy Pitchfork letterpress master cleanse, sartorial hoodie taxidermy Brooklyn salvia hashtag. McSweeney's ethical art party biodiesel fixie. Pitchfork Kickstarter leggings aesthetic tattooed Godard, kitsch keffiyeh McSweeney's lomo listicle fixie flexitarian High Life ennui.
				<br />
				<br />
				<img src="images/image.png" />
				<br />
				<br />
				Mlkshk pickled tousled hoodie. Pork belly mustache ethical tofu Wes Anderson cred. Kale chips wolf drinking vinegar umami Carles, vegan chillwave beard shabby chic Echo Park you probably haven't heard of them craft beer. Readymade Neutra raw denim dreamcatcher fap, migas craft beer master cleanse. Portland slow-carb skateboard biodiesel cred next level, four loko mumblecore. Cred ennui Pinterest viral, disrupt Tumblr High Life cronut jean shorts 3 wolf moon polaroid cornhole pop-up wayfarers. Fap Intelligentsia cred Pitchfork American Apparel cray, church-key whatever.
				<br />
				<br />
				Vinyl vegan sartorial <a href="#">aesthetic bitters</a> hella. Neutra bitters tousled locavore, hashtag trust fund bespoke Blue Bottle. Four dollar toast sriracha organic, twee hella Tumblr flannel keffiyeh beard polaroid cray put a bird on it. Swag four dollar toast cred pop-up. Occupy Pitchfork letterpress master cleanse, sartorial hoodie taxidermy Brooklyn salvia hashtag. McSweeney's ethical art party biodiesel fixie. Pitchfork Kickstarter leggings aesthetic tattooed Godard, kitsch keffiyeh McSweeney's lomo listicle fixie flexitarian High Life ennui.
				<p>Pinterest High Life authentic Blue Bottle squid. Fixie hella tousled, beard organic scenester pour-over Blue Bottle seitan trust fund twee fap. Pork belly butcher seitan cray 3 wolf moon. Actually selfies YOLO PBR&B tousled PBR. Cray Portland banjo, mlkshk Wes Anderson four loko flannel distillery twee tilde bicycle rights small batch. Gastropub church-key narwhal four dollar toast leggings next level. Hoodie raw denim meditation you probably haven't heard of them letterpress.
				<br />
				<br />
				Vinyl vegan sartorial aesthetic bitters hella. <a href="#">Neutra bitters</a> tousled locavore, hashtag trust fund bespoke Blue Bottle. Four dollar toast sriracha organic, twee hella Tumblr flannel keffiyeh beard polaroid cray put a bird on it. Swag four dollar toast cred pop-up. Occupy Pitchfork letterpress master cleanse, sartorial hoodie taxidermy Brooklyn salvia hashtag. McSweeney's ethical art party biodiesel fixie. Pitchfork Kickstarter leggings aesthetic tattooed Godard, kitsch keffiyeh McSweeney's lomo listicle fixie flexitarian High Life ennui.
				<br />
				<br />
				<img src="images/image.png" />
				<br />
				<br />
				Mlkshk pickled tousled hoodie. Pork belly mustache ethical tofu Wes Anderson cred. Kale chips wolf drinking vinegar umami Carles, vegan chillwave beard shabby chic Echo Park you probably haven't heard of them craft beer. Readymade Neutra raw denim dreamcatcher fap, migas craft beer master cleanse. Portland slow-carb skateboard biodiesel cred next level, four loko mumblecore. Cred ennui Pinterest viral, disrupt Tumblr High Life cronut jean shorts 3 wolf moon polaroid cornhole pop-up wayfarers. Fap Intelligentsia cred Pitchfork American Apparel cray, church-key whatever.
				<br />
				<br />
				Vinyl vegan sartorial <a href="#">aesthetic bitters</a> hella. Neutra bitters tousled locavore, hashtag trust fund bespoke Blue Bottle. Four dollar toast sriracha organic, twee hella Tumblr flannel keffiyeh beard polaroid cray put a bird on it. Swag four dollar toast cred pop-up. Occupy Pitchfork letterpress master cleanse, sartorial hoodie taxidermy Brooklyn salvia hashtag. McSweeney's ethical art party biodiesel fixie. Pitchfork Kickstarter leggings aesthetic tattooed Godard, kitsch keffiyeh McSweeney's lomo listicle fixie flexitarian High Life ennui.
								
				</p>
			</div>						
		</div> <!-- end row -->		
	</div>
<!-- end main content -->